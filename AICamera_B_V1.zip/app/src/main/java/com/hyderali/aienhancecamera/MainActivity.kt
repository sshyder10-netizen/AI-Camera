package com.hyderali.aienhancecamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: ImageButton
    private lateinit var statusText: TextView
    private var imageCapture: ImageCapture? = null
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        captureButton = findViewById(R.id.captureButton)
        statusText = findViewById(R.id.statusText)
        captureButton.setOnClickListener { takePhoto() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, results: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_LONG).show()
    }

    private fun startCamera() {
        ProcessCameraProvider.getInstance(this).addListener({
            val provider = ProcessCameraProvider.getInstance(this).get()
            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            statusText.text = "AI Enhance Camera"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        captureButton.isEnabled = false
        statusText.text = "Enhancing…"
        val file = File.createTempFile("original_", ".jpg", cacheDir)
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    captureButton.isEnabled = true
                    statusText.text = "Capture failed"
                    Toast.makeText(this@MainActivity, exception.message ?: "Capture failed", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                executor.execute {
                    try {
                        val source = BitmapFactory.decodeFile(file.absolutePath)
                            ?: error("Could not decode image")
                        val enhanced = AutoEnhancer.enhance(source)
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "AI_Enhanced_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Enhance Camera")
                        }
                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            ?: error("Could not create gallery item")
                        contentResolver.openOutputStream(uri).use { out ->
                            check(enhanced.compress(Bitmap.CompressFormat.JPEG, 98, out))
                        }
                        source.recycle()
                        enhanced.recycle()
                        file.delete()
                        runOnUiThread {
                            captureButton.isEnabled = true
                            statusText.text = "✓ Enhanced & saved"
                            Toast.makeText(this@MainActivity, "Enhanced photo saved to Gallery", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            captureButton.isEnabled = true
                            statusText.text = "Enhancement failed"
                            Toast.makeText(this@MainActivity, e.message ?: "Processing failed", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}

object AutoEnhancer {
    fun enhance(input: Bitmap): Bitmap {
        val w = input.width
        val h = input.height
        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val pixels = IntArray(w * h)
        input.getPixels(pixels, 0, w, 0, 0, w, h)

        var sum = 0.0
        for (c in pixels) {
            sum += 0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)
        }
        val avg = sum / pixels.size
        val contrast = when {
            avg < 70 -> 1.18f
            avg < 105 -> 1.12f
            avg > 190 -> 1.05f
            else -> 1.08f
        }
        val brightness = if (avg < 80) 10f else if (avg < 115) 5f else 0f

        for (i in pixels.indices) {
            val c = pixels[i]
            var r = 128f + (Color.red(c) - 128f) * contrast + brightness
            var g = 128f + (Color.green(c) - 128f) * contrast + brightness
            var b = 128f + (Color.blue(c) - 128f) * contrast + brightness
            val lum = 0.2126f * r + 0.7152f * g + 0.0722f * b
            val sat = if (lum > 220f) 1.04f else 1.10f
            r = lum + (r - lum) * sat
            g = lum + (g - lum) * sat
            b = lum + (b - lum) * sat
            pixels[i] = Color.rgb(
                r.coerceIn(0f, 250f).toInt(),
                g.coerceIn(0f, 250f).toInt(),
                b.coerceIn(0f, 250f).toInt()
            )
        }
        output.setPixels(pixels, 0, w, 0, 0, w, h)
        return output
    }
}
