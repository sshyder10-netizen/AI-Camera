AI CAMERA — OPTION B — VERSION 1

Android 16 target (API 36), CameraX, automatic on-device photo enhancement,
and gallery saving.

PHONE BUILD:
1. Download this ZIP.
2. Extract it completely.
3. Open AndroidIDE.
4. Open the extracted AICamera_B_V1 folder as an existing project.
5. Wait for Gradle sync/downloads.
6. Use Build/Run to install the APK.
7. Grant camera permission.
8. Take a photo and check the Gallery.

This V1 uses lightweight computational enhancement. A stronger neural-network
AI enhancement engine can be added after the first build works.
